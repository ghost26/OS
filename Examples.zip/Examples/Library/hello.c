#include <stdio.h>

void hello() {
	printf("Hello, world!\n");
	//return 0;
}
